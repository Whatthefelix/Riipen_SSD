﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Riipen_SSD.DAL.Repositories.Interfaces
{
    public interface ITeamRepository : IRepository<Team>
    {
        // Add team specific method contracts here
    }
}