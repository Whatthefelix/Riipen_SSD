﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Riipen_SSD.AdminViewModels
{
    public class ParticipantVM
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string TeamName { get; set; }

    }
}